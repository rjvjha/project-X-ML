# project-X-ML
This demo app uses CameraX API and Firebase ML Kit labeling API to label and to analyze bar codes, detect faces, or recognize famous landmarks
